This is a work done by Ivan Kabadzhov and Dion Dermaku.

To generate the images in terminal:

$ cd eyden-tracer-01-master/src
$ g++ -o main main.cpp `pkg-config opencv --cflags --libs`
$ ./make
